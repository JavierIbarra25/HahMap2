import java.util.HashMap;

public class CountDuplicates { 
    
    public static int[] removeDuplicates(int[] nums){

        HashMap<Integer, Boolean> map = new HashMap<Integer, Boolean>();
        int[] resultArray = new int[nums.length];
        int count = 0; // Contador para el número de elementos únicos


        if (nums.length == 0) {
            return new int[0]; // Retorna un array vacío si la entrada está vacía
        }

        for (int i = 0; i < nums.length; i++) {
            if (!map.containsKey(nums[i])) {
                map.put(nums[i], true);
                resultArray[count] = nums[i];
                count++;
            }
        }

        int[] finalResult = new int[count];
        for (int i = 0; i < count; i++) {
            finalResult[i] = resultArray[i];
        }

        return finalResult;
    }

    public static void main(String[] args) {
        int[] input1 = {1, 1, 2, 3, 4, 4, 5, 6, 7, 7};
        int[] output1 = removeDuplicates(input1);
        System.out.print("Output: ");
        for (int i = 0; i < output1.length; i++) {
            System.out.print(output1[i] + " ");
        }
        System.out.println();
    }
}
