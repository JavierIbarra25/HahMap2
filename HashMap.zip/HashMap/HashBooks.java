import java.util.HashMap;
import java.util.Map;

public class HashBooks {

    public static String stockSummary(String[] stocklist, String[] categories) {
        // Verificar si las entradas están vacías
        if (stocklist == null || stocklist.length == 0 || categories == null || categories.length == 0) {
            return "";
        }

        // Crear un mapa para almacenar la suma de libros por categoría
        Map<String, Integer> categoryTotals = new HashMap<>();

        // Inicializar las categorías en el mapa con valor 0
        for (int i = 0; i < categories.length; i++) {
            categoryTotals.put(categories[i], 0);
        }

        // stocklist
        for (int i = 0; i < stocklist.length; i++) {
            // Dividir el código del libro en código y cantidad
            String[] parts = stocklist[i].split(" ");
            String uno = parts[0];
            int num = Integer.parseInt(parts[1]);

            // Obtener la categoría del libro (primer carácter del código)
            String categoryL = uno.substring(0, 1);

            // Actualizar la suma de libros por categoría
            if (categoryTotals.containsKey(categoryL)) {
                categoryTotals.put(categoryL, categoryTotals.get(categoryL) + num);
            }
        }

        String result = "";
        for (int i = 0; i < categories.length; i++) {
            String category = categories[i];
            int totalStock = categoryTotals.get(category);
 
                result += "(" + category + " : " + totalStock + ")";
                if (i < categories.length - 1) {
                    result += " - ";
                }
            }

        return result.toString();
    }

    public static void main(String[] args) {
        // Ejemplo de prueba
        String[] stocklist = {"ABART 20", "CDXEF 50", "BKWRK 25", "BTSQZ 89", "DRTYM 60"};
        String[] categories = {"A", "B", "C", "W"};

        String result = stockSummary(stocklist, categories);
        System.out.println(result); // "(A : 20) - (B : 114) - (C : 50)"
    }
}