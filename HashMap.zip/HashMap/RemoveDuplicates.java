public class RemoveDuplicates {

    public static int[] removeDuplicates(int[] nums) {
        if (nums.length == 0) {
            return new int[0]; // Retorna un array vacío si la entrada está vacía
        }

        int[] resultArray = new int[nums.length];
        int count = 0; // Contador para el número de elementos únicos

        for (int i = 0; i < nums.length; i++) {
            boolean isDuplicate = false;

            // Verificar si el número ya está en el array de resultados
            for (int j = 0; j < count; j++) {
                if (nums[i] == resultArray[j]) {
                    isDuplicate = true;
                    break;
                }
            }

            // Si no es un duplicado, agregarlo al array de resultados
            if (!isDuplicate) {
                resultArray[count] = nums[i];
                count++;
            }
        }

        // Crear un array final con el tamaño correcto
        int[] finalResult = new int[count];
        for (int i = 0; i < count; i++) {
            finalResult[i] = resultArray[i];
        }

        return finalResult;
    }

    public static void main(String[] args) {
        int[] input1 = {1, 1, 2};
        int[] output1 = removeDuplicates(input1);
        System.out.print("Output: ");
        for (int i = 0; i < output1.length; i++) {
            System.out.print(output1[i] + " ");
        }
        System.out.println();
    }
}